
This directory holds plugins and plugin configurations.

