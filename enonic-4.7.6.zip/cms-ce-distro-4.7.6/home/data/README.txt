
This directory is used for additional data, like blobs and resources.

