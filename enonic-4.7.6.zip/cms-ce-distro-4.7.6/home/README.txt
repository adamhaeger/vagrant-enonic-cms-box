
This directory contains a sample home directory.
